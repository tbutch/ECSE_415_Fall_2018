The structure for the images and the Haar features must be as follows:

260747124_assignment4.ipynb
haarcascade_frontalface_default.xml
image_dataset
	|-bj_novak
		|- Edited --> Pictures
	|-jenna_fischer
		|- Edited --> Pictures
	|-rainn_wilson 
		|-Edited --> Pictures
	|-steve_carell
		|-Edited --> Pictures
	|-steve_krasinski
		|-Edited --> Pictures
	|-the_office group.jpg
	